# Deutsch SRS — Samsung Galaxy S23 Ultra

Android Studio project containing 1170 verb records parsed from the supplied PDF.

Included in this build:
- local 1170-card database;
- two examples per card (generated placeholders; the source PDF does not provide examples);
- Präteritum, Partizip II, Rektion and Russian translation;
- management formatted as `__ + Akk.`, `an + Akk.` etc.;
- SRS: 20 min -> 2 h -> 1 d -> 3 d -> longer intervals;
- four self-ratings;
- typed verb recall;
- daily challenge with own sentences;
- progress stored in WebView localStorage on the phone.

The AI sentence checker is deliberately not embedded with an API key. For real AI checking, add a secure server endpoint and call it from the challenge screen.

Build with Android Studio -> Build APK(s). Debug APK: app/build/outputs/apk/debug/app-debug.apk

## v1.1 fixes (see chat with Claude for full detail)

The original placeholder examples had a systematic bug: the conjugated verb
form was copy-pasted next to "Ich" instead of being conjugated for 1st
person, reflexive pronouns ("sich") were never adapted to the subject, and
separable prefixes (an-, ab-, auf- ...) were never split to the end of the
clause. All 1170 x 2 examples were regenerated with a small rule-based
conjugator (ich-/wir-form derived from the infinitive; known irregulars for
sein/haben/modal verbs/wissen/nehmen/treten hardcoded; separable prefixes
detected against the verb list itself to avoid false splits; impersonal
verbs like regnen/gelingen use "Es"). Object phrases use personal pronouns
(ihn/ihm) rather than fixed nouns so they stay natural across verbs that
expect a person as their object.

Known simplification: for verbs whose Rektion lists two alternatives
separated by ";" (e.g. `halten` = "jemanden für etwas halten"), only one
alternative is shown in the example — the sentence is correct German, it
just doesn't always showcase every governed preposition. Ambiguous
separable/inseparable prefixes (durch-, über-, um-, unter-, wieder-, voll-,
wider-) are conservatively treated as inseparable/attached.

`checkSentence()` in the daily-challenge screen used to search the typed
sentence for the bare infinitive, which a correctly conjugated sentence
almost never contains ("spreche" doesn't contain "sprechen") — so correct
answers were being marked wrong. It now checks the sentence against a set
of derived stem/conjugation candidates (incl. known irregulars and
ae/oe/ue/ss ASCII-umlaut spellings) instead.

No gradlew/gradle-wrapper.jar is included (couldn't be generated in this
environment without network access). Android Studio will offer to create
the wrapper automatically the first time you open the project — accept
that prompt (and accept any suggested AGP/Gradle version bump too).
