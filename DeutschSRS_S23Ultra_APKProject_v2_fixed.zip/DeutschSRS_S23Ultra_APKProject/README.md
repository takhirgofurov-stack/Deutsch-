# Deutsch SRS — Samsung Galaxy S23 Ultra

Android Studio project containing 1170 verb records parsed from the supplied PDF.

Included in this build:
- local 1170-card database;
- two examples per card (generated placeholders; the source PDF does not provide examples);
- Präteritum, Partizip II, Rektion and Russian translation;
- management formatted as `__ + Akk.`, `an + Akk.` etc.;
- SRS: 20 min -> 2 h -> 1 d -> 3 d -> longer intervals;
- four self-ratings;
- typed verb recall;
- daily challenge with own sentences;
- progress stored in WebView localStorage on the phone.

The AI sentence checker is deliberately not embedded with an API key. For real AI checking, add a secure server endpoint and call it from the challenge screen.

Build with Android Studio -> Build APK(s). Debug APK: app/build/outputs/apk/debug/app-debug.apk
