package com.deutschsrs.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView web;
    private static final int REQ_SPEECH = 4201;
    private static final int REQ_PICK_VIDEO = 4202;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        web.addJavascriptInterface(new VideoBridge(), "AndroidVideo");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    // ---------- голосовой ввод (кнопка микрофона в чате) ----------
    private class VoiceBridge {
        @JavascriptInterface
        public void startListening() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Sprich auf Deutsch…");
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(intent, REQ_SPEECH);
                    } else {
                        Toast.makeText(MainActivity.this, "Голосовой ввод недоступен на этом устройстве", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    // ---------- выбор видеофайла (этап 1 функции субтитров) ----------
    private class VideoBridge {
        @JavascriptInterface
        public void pickVideo() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("video/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        startActivityForResult(intent, REQ_PICK_VIDEO);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Не удалось открыть выбор файлов: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                final String escaped = JSONObject.quote(results.get(0));
                web.post(new Runnable() {
                    @Override public void run() {
                        web.evaluateJavascript("window.onSpeechResult && window.onSpeechResult(" + escaped + ");", null);
                    }
                });
            }
            return;
        }

        if (requestCode == REQ_PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            final Uri uri = data.getData();
            if (uri == null) return;
            web.post(new Runnable() {
                @Override public void run() {
                    web.evaluateJavascript("window.onVideoImportStart && window.onVideoImportStart();", null);
                }
            });
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        File outFile = new File(getCacheDir(), "current_video.mp4");
                        ContentResolver cr = getContentResolver();
                        InputStream in = cr.openInputStream(uri);
                        OutputStream out = new FileOutputStream(outFile);
                        byte[] buf = new byte[1 << 16];
                        int n;
                        while ((n = in.read(buf)) != -1) {
                            out.write(buf, 0, n);
                        }
                        in.close();
                        out.close();
                        final String escapedPath = JSONObject.quote("file://" + outFile.getAbsolutePath());
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onVideoImported && window.onVideoImported(" + escapedPath + ");", null);
                            }
                        });
                    } catch (Exception e) {
                        final String escapedErr = JSONObject.quote(String.valueOf(e.getMessage()));
                        web.post(new Runnable() {
                            @Override public void run() {
                                web.evaluateJavascript("window.onVideoImportError && window.onVideoImportError(" + escapedErr + ");", null);
                            }
                        });
                    }
                }
            }).start();
        }
    }
}
